A penepma16 simulation of 100 nm of Cu on Si

This was inspired by an example from John Donovan.

The simulation was to test the new penepma16 GUI from
CalcZAF. The simulation was run for 12 hours.

The .in file was generated from the GUI.

I like to compute the low energy region of the spectrum
so I set the low energy limits to 100 eV.